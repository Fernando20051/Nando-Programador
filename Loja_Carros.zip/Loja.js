//início do programa 
const card_Item = document.querySelector('#data_img');
const publicidade = document.querySelectorAll('#data_img img');
var pubView = document.getElementById('video1');
let index =0, control = 1;
function removeAndAdd()
{
 index++;
 if (index > publicidade.length - 1)
 {
   index = 0; 
 }
 card_Item.style.transform = `translateX(${-index*550}px)`;
}
setInterval(removeAndAdd,1000);
var btnPublicidade = document.querySelector('#publico');
document.querySelector('#publico').addEventListener('click',()=>{

 if (control === 1) 
 {
 card_Item.style.display ='none';
 setTimeout(()=>{
   document.querySelector('.video').style.display ='block';
 pubView.play();
 pubView.muted = true;
btnPublicidade.textContent = 'Ver Imagens';
 },600);
  control++;
 } 
 else
 {
document.querySelector('.video').style.display ='none';
setTimeout(()=>{
card_Item.style.display ='flex';
btnPublicidade.textContent ='Ver Publicidade'; 
},500);
control = 1;
 }
});
 //botão menu
function closeMenu() {
 const navMenu = document.querySelector('.nav-menu');
    navMenu.classList.toggle('active');
 navMenu.addEventListener('click',()=> {
navMenu.classList.remove('active');
document.querySelector('.header').classList.remove('div-Menu');
 });
 document.querySelector('.header').classList.add('div-Menu');
document.querySelector('.hamburger').addEventListener('click',()=>{
 document.querySelector('.header').classList.toggle('div-Menu');
});
}
//Reservar o carro.
function Reservado(){
const total_carros= document.getElementById('count-car');
total_carros.style.display ='block';
total_carros.innerText = 1;
const img_default = document.querySelector("[alt='Car Image']");
 if (total_carros.textContent== 1) 
 {
img_default.src= document.getElementById('car-vendido').src;
 setTimeout(Reservado=> {
[document.querySelector('#carros'),document.querySelector('#carros1')].forEach(vender =>{
    vender.classList.toggle('carro_vendido');
  });
 });
}
}
//dados do usuário logado
 function obterDados() {
[document.querySelector('#userLogin'),document.querySelector('#userlogado')].forEach((logado)=>{
    logado.classList.toggle('userdata');
  });
 }
//submeter os formulários
const forms = document.querySelectorAll('.formulario');
forms.forEach(submeter =>{
  submeter.addEventListener('submit',function(submetido){
  submetido.preventDefault();
  //submeter.submit();
  })
});
 const senha=document.querySelectorAll('#senha,#confirmarSenha');
//validar o e-mail.
document.querySelector('#btncadastrar').addEventListener('click',()=>{
const usuario = document.querySelector('#email');
 const email_user = new RegExp(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
 if (email_user.test(usuario.value))
 {
  for (var t = 0; t < senha.length; t++) 
  {
  senha.item(t).value.length >= 8 && senha.item(0).value ==senha.item(1).value ? true : window.alert("Senha incorreta!");
  }
 }
else
{
window.alert('O seu e-mail está incorrecto, por favor Insira um e-mail válido!');
}
});
//e-mail logado
 document.querySelector('#btnLogar').addEventListener('click',()=>{
const email1 = document.querySelector('#email1');
var e_mail = new RegExp(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
const tota_pagar = document.getElementById('count-car');
 if (e_mail.test(email1.value) && document.getElementById('password').value.length >= 8)
 {
  if (tota_pagar.textContent > 0)
  {
  document.querySelectorAll('.paga-meu-car').item(1).value = email1.value;
   comprador();
  }
 }
 else
 {
  window.alert("Dados incorretos. Tente verificar o e-mail ou a senha se está correto!");
 } 
 });
//validar a senha

//Cadastro do cliente 
function exibirCadastro() {
 const user1 =document.querySelector('#cadastrar');
 const user2 = document.querySelector('#cadastrar1');
  [user1,user2].forEach((dados_cadastrados)=>{
    dados_cadastrados.classList.toggle('cadastroOk');
  });
}
document.getElementById('activelogin').addEventListener('click', function() {
  setTimeout(()=>{
 setTimeout(obterDados,600);
  exibirCadastro();
  },1000);
});
document.getElementById('link-cadastro').addEventListener('click',()=>{
   setTimeout(()=>{
  setTimeout(exibirCadastro,600);
  obterDados();
   },1000);
});
//comprar carro/s
function clientes() {
 const tot_car =  document.getElementById('count-car').textContent
 if (tot_car > 0) {
 [document.querySelector('#carros'),document.querySelector('#carros1')].forEach(vender =>{
    vender.classList.toggle('carro_vendido');
  });
 } else {
 window.alert('Adiciona pelo menos um carro ao carrinho!');
 }
};
document.addEventListener('DOMContentLoaded',() => {
const carAdd = document.querySelector('.add-car');
 const carDelete = document.querySelector('.delete-car');
 const cartItemsContainer = document.querySelector('.itemcomprado');
const imagcar = document.querySelector('.car-image');
  carAdd.addEventListener('click', () => {
  const newCartItem =
 document.createElement('div');
 newCartItem.classList.add('cart-item');
newCartItem.innerHTML = `
<img src="${carro_escolhido.src}" alt="Car Image" class="car-image">
 <img src="Del_car.png" alt="Delete Icon" class="icon delete-cart-item">
<img src="Add_car.png" alt="Cart Icon" class="icon cart-icon">
        `;
cartItemsContainer.appendChild(newCartItem);
const deleteCartItem = newCartItem.querySelector('.delete-cart-item');
deleteCartItem.addEventListener('click', () => {
 cartItemsContainer.removeChild(newCartItem);
 document.getElementById('count-car').textContent =1;
        });
    });
 carDelete.addEventListener('click', () => {
   while (cartItemsContainer.firstElementChild) {
cartItemsContainer.removeChild(cartItemsContainer.firstElementChild);
document.getElementById('count-car').textContent =1;
        }
    });
});
//seleccionar o carro 
const carro_comprado = document.querySelectorAll('.btn-view');
const op_car = document.querySelectorAll('#car-vendido');
const carro_escolhido = document.querySelector('.car-image');
const my_car = document.querySelector('#my-car'); 
const viewCar = document.querySelector('#view-client');
const previewcar = document.querySelector('#view-car-data'); 
var vetCar =new Array(16);

function carros()
{
 carro_comprado.forEach((car)=> {
   car.addEventListener('click',()=>{
 switch (car) {
case carro_comprado.item(0):
  my_car.src= op_car.item(0).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(1):
 my_car.src = op_car.item(1).src; 
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(2):
my_car.src= op_car.item(2).src; 
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(3):
 my_car.src= op_car.item(3).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(4):
 my_car.src= op_car.item(4).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(5):
my_car.src= op_car.item(5).src; 
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(6):
 my_car.src= op_car.item(6).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(7):
 my_car.src= op_car.item(7).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(8):
  my_car.src= op_car.item(8).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(9):
  my_car.src= op_car.item(9).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(10):
  my_car.src= op_car.item(10).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(11):
  my_car.src= op_car.item(11).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(12):
  my_car.src= op_car.item(12).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(13):
  my_car.src= op_car.item(13).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(14):
  my_car.src= op_car.item(14).src;
 carro_escolhido.src = my_car.src;
break;
case carro_comprado.item(15):
  my_car.src= op_car.item(15).src;
 carro_escolhido.src = my_car.src;
break;
  default:
  carro_escolhido.src = carro_escolhido.src;
  }
 view_my_car();
 });
});
}
 setTimeout(carros,350);
// Requerendo o carro 
function view_my_car()
{
var total_car = document.getElementById('count-car');
 if (total_car.textContent>= 6) 
{
document.getElementById('carrinho').src ='./carrinho_cheio.png';
 total_car.style.display='none';
 obterDados();
 [viewCar,previewcar].forEach(view => {
  view.classList.toggle('car-client');
 });
 setTimeout(()=>{
   window.alert('Atingiste o limite da reserva! clica para comprar.');
 },1500);
} 
else{
 [viewCar,previewcar].forEach(view => {
  view.classList.toggle('car-client');
 });
 }
}
 document.getElementById('addvalue').addEventListener('click',()=> {
 setTimeout(()=>{
   document.getElementById('add-carrinho').style.display ='block';
 document.getElementById('count-car').innerText++;
 setTimeout(()=>{
 document.getElementById('add-carrinho').style.display ='none';
document.getElementById('count-car').style.display ='block';
const cartItemsContainer = document.querySelector('.itemcomprado');
 const listcar =
document.createElement('div');
 listcar.classList.add('cart-item');
listcar.innerHTML = `
<img src="${carro_escolhido.src}" alt="Car Image" class="car-image">
 <img src="Del_car.png" alt="Delete Icon" class="icon delete-cart-item">
<img src="Add_car.png" alt="Cart Icon" class="icon cart-icon">
        `;
cartItemsContainer.appendChild(listcar);
  view_my_car();
 },1500);
 },500);
 });
document.getElementById('newsletter-form').addEventListener('submit', function(event) {
    event.preventDefault();
 const email = event.target.querySelector('input[type="email"]').value;
 window.alert(`Obrigado por se inscrever! Você receberá nossas novidades no e-mail: ${email}`);
    event.target.reset();
});
document.addEventListener('scroll',()=>{
  document.getElementById('count-car').style.display ='none';
});

function service() {
  window.alert('Para mais informações, por favor entre em contacto: +244 1234-5678');
}
//pagamento do carro/s
function pagamento_car() {
 [document.querySelector(' #item-comprado'),document.querySelector('#view-comprar')].forEach(pagar=>{
   pagar.classList.toggle('car-pago');
 }); 
}
 const btncomprar = document.querySelectorAll('#negociado');
 btncomprar.forEach(clickbtn=>{
  clickbtn.addEventListener('click',()=>{
 switch (clickbtn) {
case btncomprar.item(0):
 Reservado();
 setTimeout(obterDados,1200);
break;
   default:
   [document.querySelector('#view-client'),document.querySelector('#view-car-data')].forEach(close=>{
close.classList.toggle('car-client');
   });
document.getElementById('count-car').innerText++; 
setTimeout(obterDados,1200);
}
  });
});

const comprador =()=>{
  obterDados();
 setTimeout(pagamento_car,1000);
}

function exibir_factura() 
{
 pagamento_car();
setTimeout(()=>{
  [document.querySelector('#facturas1'),document.querySelector('#facturas')].forEach(factura=>{
factura.classList.toggle('factura');
  });
  },1300);
}
let global = 0;
document.getElementById('btn-pagar').addEventListener('click',()=>{
  const data_client = document.querySelectorAll('.dono-car');
 if (global === data_client.length) {
  document.querySelectorAll('#statu-cliente').forEach(statu=>{
  statu.textContent ='Pago'; 
  });
  document.querySelector('#usuarios').textContent= data_client.item(0).value;
document.getElementById('titular').textContent = data_client.item(6).value;
document.getElementById('localcliente').textContent = data_client.item(1).value;
document.getElementById('quantidade').innerText= document.getElementById('count-car').innerText; 
 document.getElementById('total').innerText = document.getElementById('total-pago').value;
document.getElementById('valores').innerText = data_client.item(3).value;

setTimeout(exibir_factura,1350);
 }
 else
 {
  for (var i = 0; i < data_client.length; i++) 
  {
 if (data_client.item(i).value ==='')
  {
   data_client.item(i).style.border ='2px solid rgba(255, 0, 0, 1)';
  continue;
  }
  else
  {
   break;
  }
  }
 }
 });

  document.querySelectorAll('.dono-car').forEach(data=>{
data.addEventListener('change',()=>{
if (data.value==="") 
    {
data.style.border ='2px solid   rgba(255, 0, 0, 1)';
//global--;
}
  else
{
  global++;
data.style.border ='2px solid rgba(0, 42, 255, 1)';
    }
    });
  });
 
const date_now = document.getElementById('data');
const date_factura = document.getElementById('date_timer');
const hours_now= document.getElementById('timer');
const tempo = new Date();
date_now.textContent = tempo.toLocaleDateString();
date_factura.textContent = date_now.textContent;
hours_now.textContent = tempo.toLocaleTimeString();
