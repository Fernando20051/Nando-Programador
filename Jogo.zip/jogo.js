/*moved game by Nando to say*/

const pergunta = document.getElementById('perguntas');

const respostas = document.getElementsByClassName('respostas');

var opBibliclica = document.querySelector('#lender');
var perguntando = new Array(6);
var respondendo = new Array(6);

perguntando = ['A frase "João dizia, pois, às multidões que saíam para ser batizadas por ele" é de?','Quantos autores são citado no novo testamento?','Onde Jesus Cristo nasceu?','A frase "O dia está próxio" é de?','Qual foi a missão de Tito?','A frase "A vida do rei da Glória" é de?'];
  
  respondendo = ['Lucas','29','Belém','Romanos','Dedicar a você','Salmos'];
  
 let vetMentir = ['Jesué','Salmos','Moisés','Salomão','80','100','Infinito','Dedicar a Deus','Dedicar em mim','Dedicar ao Senhor','Jerusalém','Palácio','Terra prometida'];
  
function confg() {
  
  var op1,op2,op3,op4;

  op1 = respostas.item(0);
  op2 = respostas.item(1);
  op3 = respostas.item(2);
  op4 = respostas.item(3);
  
  var listadados = new Set();
  listadados.add(op1.textContent);
  listadados.add(op2.textContent);
  listadados.add(op3.textContent);
  listadados.add(op4.textContent);

if(pergunta.textContent == perguntando[0]){
 
 pergunta.textContent = perguntando[1];
 respostas.item(0).innerText = respondendo[1];
 respostas.item(1).innerText = vetMentir[4];
 respostas.item(2).innerText = vetMentir[5];
 respostas.item(3).innerText = vetMentir[6];
}

else if (pergunta.innerText == perguntando.slice(1,2)) {
  
 pergunta.innerText = perguntando.slice(2,3);
respostas.item(0).innerText = vetMentir.slice(10,11);
 respostas.item(1).innerText = respondendo.slice(2,3);
 respostas.item(2).innerText = vetMentir.slice(11,12);
 respostas.item(3).innerText = vetMentir[12];
}
else if (pergunta.innerHTML == perguntando.slice(2,3)) {
pergunta.textContent = perguntando.slice(3,4);
 respostas.item(0).innerText = vetMentir.slice(1,2);
respostas.item(1).innerText = respondendo.slice(3,4);
respostas.item(2).innerText = vetMentir.slice(3,4);
respostas.item(3).innerText = vetMentir.slice(0,1);
}
else if(pergunta.textContent == perguntando.slice(3,4)) {
  
 pergunta.innerText = perguntando.slice(4,5);
 respostas.item(0).innerText = vetMentir.slice(7,8);
respostas.item(1).innerText = vetMentir.slice(8,9);
respostas.item(2).innerText = respondendo.slice(4,5);
respostas.item(3).innerText = vetMentir.slice(9,10);
}
else {
  pergunta.innerHTML = perguntando.slice(5,6);
respostas.item(0).innerText = vetMentir.slice(3,4);
respostas.item(1).innerText = vetMentir.slice(0,1);
respostas.item(2).innerText = vetMentir.slice(2,3);
respostas.item(3).innerText = respondendo.slice(5,6);
}

}

const jogador = document.getElementById('jogadores');
var talName;

const preencherdata = () =>{
  
  for (var i = 0; i <= 6; i++) {
   if (pergunta.textContent !== perguntando[i]) {
     
 pergunta.textContent = perguntando.slice(0,1);
   respostas.item(0).textContent = respondendo.slice(0,1);
   respostas.item(1).textContent = vetMentir.slice(1,2); 
   respostas.item(2).textContent=vetMentir.slice(2,3);  
   respostas.item(3).textContent = respondendo.slice(3,4);
   }
 else{
     window.alert('O botão iniciar já foi precionado por alguém  🤔');
   }
  }
setTimeout(()=> {
  
  if (jogador.textContent === "Nome") {
  jogador.textContent = window.prompt('Insira o seu nome para continuar a jogar.🤓  ✍ <<Se não inserir o nome, não consigo te identificar no topo do jogo.>> 😵 ☝️');
  
  talName = jogador.textContent;
}
  
const percentagem = document.getElementById('porcento').innerHTML = 'M';
clearInterval(timegame('0'),1000);
document.getElementById('nome').classList.add('classLabel');
},1000);
}

document.querySelector('.decidir').addEventListener('click', preencherdata);

const clicknobtnver = ()=>{
  
 var verCapitulo = new Array(6);
 
  verCapitulo=['Lucas 3:7','É na Contracapa do livro','Lucas 2:7','Ramanos 13:11', '2 Corintios 8:16','Salmos 24:1'];
  
  switch (pergunta.innerText) {
    
  case 'A frase "João dizia, pois, às multidões que saíam para ser batizadas por ele" é de?':
    window.alert('Consulte o Livro novo testamento em 👉'+ verCapitulo[0]+'. 😇');
     break;
      
  case 'Quantos autores são citado no novo testamento?':
     window.alert('Consulte o Livro novo testamento em 👉'+ verCapitulo[1]+'. 😇');
        break;
        
  case 'Onde Jesus Cristo nasceu?':
     window.alert('Consulte o Livro novo testamento em 👉'+ verCapitulo[2]+'. 😇');
        break;
    
  case 'A frase "O dia está próxio" é de?':
     window.alert('Consulte o Livro novo testamento em 👉'+ verCapitulo[3]+'. 😇');
        break;
        
 case 'Qual foi a missão de Tito?':
     window.alert('Consulte o Livro novo testamento em 👉'+ verCapitulo[4]+'. 😇');
        break;
        
  case 'A frase "A vida do rei da Glória" é de?':
     window.alert('Consulte o Livro novo testamento em 👉'+ verCapitulo[5]+'. 😇');
        break;
        
    default:
      window.alert('Nenhuma opção está activa no momento  ❌ '+' Clica no botão iniciar para ver opções.👇');
  }
  
};

opBibliclica.addEventListener('click',clicknobtnver);

const feichar = (function() {
  
  var feicho = document.createElement('a');
  feicho.href ='./jogos.html';
})

document.querySelector('.decidir1').addEventListener('click',feichar);

//primeira opção
const config1 = (function(valor1, valor2) {

const  contcerto = document.getElementsByClassName('respostas').item(0).textContent; 

valor1 = respondendo[0];
valor2 = respondendo[1];
  
  switch (contcerto) {
    case valor1:
document.getElementsByClassName('valortrue').item(0).classList.
add('addcerto');
  setTimeout(()=>{
document.getElementsByClassName('valortrue').item(0).classList.
remove('addcerto');

 window.alert('Resposta Certa. 😉  🙏 ');
 cont2.innerText++;
 fim('0');
 confg();
  },2000);
      break;
      
    case valor2:
document.getElementsByClassName('valortrue').item(0).classList.
add('addcerto');
  setTimeout(()=>{
document.getElementsByClassName('valortrue').item(0).classList.
remove('addcerto');
 window.alert('Resposta Certa. 😉  🙏 ');
  cont2.innerText++;
  fim('0');
 confg();
  },2000);
      break;
    
    default:
  if(respostas.item(0).textContent== 'Resposta1'){
  window.alert('Ainda não Clicaste no botão Iniciar '+' Clicar agora. 👇 🤔');
  } else {
 document.getElementsByClassName('valortrue').item(0).classList.add('adderrado');
 setTimeout(()=>{
document.getElementsByClassName('valortrue').item(0).classList.remove('adderrado');
window.alert('Resposta Errada. 😳 👉  cosulte a Bíblia.');
cont1.innerText++;
 fim('0');
confg();
 },2000);
   }
}
  return valor;
});
//segunda opção
const config2 = (function(valor1, valor2) {

const  contcerto = document.getElementsByClassName('respostas').item(1).textContent; 

valor1 = respondendo[2];
valor2 = respondendo[3];
  
  switch (contcerto) {
    case valor1:
document.getElementsByClassName('valortrue').item(1).classList.
add('addcerto');
  setTimeout(()=>{
document.getElementsByClassName('valortrue').item(1).classList.
remove('addcerto');

 window.alert('Resposta Certa. 😉  🙏 ');
  cont2.innerText++;
  fim(0);
 confg();
  },2000);
      break;
      
    case valor2:
       document.getElementsByClassName('valortrue').item(1).classList.
add('addcerto');
  setTimeout(()=>{
document.getElementsByClassName('valortrue').item(1).classList.
remove('addcerto');

 window.alert('Resposta Certa. 😉  🙏 ');
  cont2.innerText++;
  fim(0);
 confg();
  },2000);
      break;
    
    default:
  if(respostas.item(1).textContent== 'Resposta2'){
  window.alert('Ainda não Clicaste no botão Iniciar '+' Clicar agora. 👇 🤔');
  } else {
document.getElementsByClassName('valortrue').item(1).classList.add('adderrado');
setTimeout(()=>{
document.getElementsByClassName('valortrue').item(1).classList.remove('adderrado');
window.alert('Resposta Errada. 😳 👉  cosulte a Bíblia.');
cont1.innerText++;
  fim(0);
confg();
 },2000);
  }
 }
  return valor;
});
//terceira opção
const config3 = (function(valor) {
const  contcerto = document.getElementsByClassName('respostas').item(2).textContent; 

valor = respondendo[4];
  
  switch (contcerto) {
    case valor:
document.getElementsByClassName('valortrue').item(2).classList.
add('addcerto');
  setTimeout(()=>{
document.getElementsByClassName('valortrue').item(2).classList.
remove('addcerto');

 window.alert('Resposta Certa. 😉  🙏 ');
  cont2.innerText++;
  fim(0);
 confg();
  },2000);
      break;
      
    default:
  if(respostas.item(2).textContent== 'Resposta3'){
  window.alert('Ainda não Clicaste no botão Iniciar '+' Clicar agora. 👇 🤔');
  } else {
 document.getElementsByClassName('valortrue').item(2).classList.add('adderrado');
setTimeout(()=>{
document.getElementsByClassName('valortrue').item(2).classList.remove('adderrado');
window.alert('Resposta Errada. 😳 👉  cosulte a Bíblia.');
cont1.innerText++;
  fim(0);
confg();
 },2000);
    }
  }
  
  return valor;
});
//Quarta opção
const config4 = (function(valor) {

const  contcerto = document.getElementsByClassName('respostas').item(3).textContent; 

valor = respondendo[5];
  
  switch (contcerto) {
    case valor:
document.getElementsByClassName('valortrue').item(3).classList.
add('addcerto');
  setTimeout(()=>{
document.getElementsByClassName('valortrue').item(3).classList.
remove('addcerto');
 window.alert('Resposta Certa. 😉  🙏 ');
 cont2.innerText++;
  fim(0);
 confg();
  },2000);
      break;
      
    default:
  if(respostas.item(3).textContent== 'Resposta4'){
  window.alert('Ainda não Clicaste no botão Iniciar '+' Clicar agora. 👇 🤔');
  } else {
document.getElementsByClassName('valortrue').item(3).classList.add('adderrado');
setTimeout(()=>{
document.getElementsByClassName('valortrue').item(3).classList.remove('adderrado');
window.alert('Resposta Errada. 😳 👉  cosulte a Bíblia.');
cont1.innerText++;
  fim(0);
confg();
 },2000);
  }
  }

  return valor;
});

const cont1 = document.getElementById('contador1');
const cont2 = document.getElementById('contador2');
const sptexto = document.getElementsByClassName('spanptodos');
clearTimeout(setTimeout,1500);
const minut = document.querySelector('#valor');

function timegame(tempo) {
  
 minut.innerHTML = eval('1*60');
 if(!talName){
  talName = 'Nome';
  jogador.textContent = 'Nome';
}

 setInterval(()=>{
   minut.innerHTML--;
   tempo = minut.textContent;
  if(tempo === minut.innerHTML && minut.textContent == 0){
    fim('0');
  }
 },2000);
 
 return tempo;
}

const fim = function(v) {
 v=0;

if(minut.textContent == v){
 
 if(cont2.textContent === 3){
  window.alert('parabéns você está indo bem 😉 continue assim 📖'+' ⭐⭐⭐');
 } else if(cont2.textContent < cont1.textContent && cont2.textContent === 0) {
 window.alert('Parece que você não gosta da Bíblia 😡'+' tente converter-se a uma igreja.⛪');
 } else if(cont2.textContent >= 4){
   window.alert('parabéns😇 continue assim.🙏 🤲Conseguiste ganhar 5 estrelas. 👉'+' ⭐⭐⭐⭐⭐');
 } else{
  window.alert('Será que você não gosta de ler a Bíblia. 😧 📖'+' ⭐⭐');
 }
 setTimeout(()=>{
   document.writeln('<h1>O tempo da sua partida já esgotou. 🤗 </h1> </br> <h1>'+document.getElementById('nome').textContent+'</h1> Conseguiste Acertar <h1>'+ cont2.textContent+' </h1> e erraste <h1>'+ cont1.textContent+' </h1>' );
 
 },2200);
 
} else {
 
return v = true; 
}
  return v;
}
