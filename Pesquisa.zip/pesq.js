var selecionar = document.getElementById('send');
var pesquisar = document.querySelector('#sended');
var valores = {
 a:['a','A','António','Ananás','Arroz','Amigo','Amaçadeira','Anel'],
 b:['b','B','Balvina','Banheiro','Bacalhão','Batata','Bandeira','Bai'],
 c:['c','C','Carlos','Catana','Crianças','Cr7','Cabinda','Carismático'],
 outros:['Daniel','Envagélio','Final','Gelado','Humano','Ino','Jamaica','Katiya','Lua','Maria','Nepal','Orgão','Pai','Que','Rei','Salvador','Tio','União','Viúva','Word','Xavier','Year','Zebra']
};

function inner() {
 var respo=document.querySelectorAll('p');
 
if(pesquisar.value =='a'|| pesquisar.value == 'A'){
 for (var i = 0; i < respo.length; i++) {
 respo.item(i).textContent = valores.a[i];
 }
} else if(pesquisar.value =='b'|| pesquisar.value == 'B'){
 for (var i = 0; i < respo.length; i++) {
 respo.item(i).textContent = valores.b[i];
 }
}
else if(pesquisar.value =='c'|| pesquisar.value == 'C'){
 for (var i = 0; i < respo.length; i++) {
 respo.item(i).textContent = valores.c[i];
 }
}
else {
 let pointer = 0;
  if (pointer == 0 && pointer < 8) {
  for (var i = 0; i < 8; i++) {
   respo.item(i).textContent= valores.outros[i];
  pointer++;
  }
  }
if (pointer >  0 && pointer <16) {
  for ( var i = 0; i < 8; i++) {
 respo.item(i).textContent= valores.outros[pointer++];
  }
  }
 if (pointer == 16 && pointer < 23) {
  for ( var i = 0; i < 8; i++) {
 respo.item(i).textContent= valores.outros[pointer++];
  }
  } 
}
 
}

pesquisar.addEventListener('input',()=> {
 if (pesquisar.value.length >0) {
  selecionar.style.display = 'grid';
  selecionar.style.gridGap= 'wrap';
selecionar.style.gap= '0px';
  inner();
 }
 else {
  selecionar.style.display = 'none';
 }
});